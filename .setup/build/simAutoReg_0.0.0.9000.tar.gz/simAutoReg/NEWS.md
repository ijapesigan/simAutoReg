# simAutoReg 0.0.0.9000 (development version)

- Simulation functions
    - AR(p)
    - VAR(p)
    - Multivariate normal data
    - Variances
