library(testthat)
library(simAutoReg)

test_check("simAutoReg")
