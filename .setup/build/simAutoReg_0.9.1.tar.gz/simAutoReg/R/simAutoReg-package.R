#' @aliases simAutoReg-package
#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom Rcpp sourceCpp
#' @useDynLib simAutoReg, .registration = TRUE
## usethis namespace: end
NULL
